import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Representa una persona mediante sus datos personales básicos.
 *
 * @author luisma
 * @version 1.0
 */
public class Persona {

    /** Documento Nacional de Identidad de la persona. */
    private int dni;
    /** Nombre de la persona. */
    private String nombre;
    /** Apellido de la persona. */
    private String apellido;
    /** Año de nacimiento de la persona. */
    private int anioNacimiento;

    /**
     * Crea una persona con sus datos personales.
     *
     * @param pDni            Documento Nacional de Identidad de la persona
     * @param pNombre         nombre de la persona
     * @param pApellido       apellido de la persona
     * @param pAnioNacimiento año de nacimiento de la persona
     */
    public Persona(int pDni, String pNombre, String pApellido, int pAnioNacimiento) {
        this.setDNI(pDni);
        this.setNombre(pNombre);
        this.setApellido(pApellido);
        this.setAnioNacimiento(pAnioNacimiento);
    }

    /**
     * Asigna el Documento Nacional de Identidad de la persona.
     *
     * @param pDni Documento Nacional de Identidad que se asignará
     */
    private void setDNI(int pDni) {
        this.dni = pDni;
    }

    /**
     * Asigna el nombre de la persona.
     *
     * @param pNombre nombre que se asignará
     */
    private void setNombre(String pNombre) {
        this.nombre = pNombre;
    }

    /**
     * Asigna el apellido de la persona.
     *
     * @param pApellido apellido que se asignará
     */
    private void setApellido(String pApellido) {
        this.apellido = pApellido;
    }

    /**
     * Asigna el año de nacimiento de la persona.
     *
     * @param pAnioNacimiento año de nacimiento que se asignará
     */
    private void setAnioNacimiento(int pAnioNacimiento) {
        this.anioNacimiento = pAnioNacimiento;
    }

    /**
     * Obtiene el Documento Nacional de Identidad de la persona.
     *
     * @return Documento Nacional de Identidad de la persona
     */
    public int getDNI() {
        return dni;
    }

    /**
     * Obtiene el nombre de la persona.
     *
     * @return nombre de la persona
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el apellido de la persona.
     *
     * @return apellido de la persona
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * Obtiene el año de nacimiento de la persona.
     *
     * @return año de nacimiento de la persona
     */
    public int getAnioNacimiento() {
        return anioNacimiento;
    }

    /**
     * Calcula la edad aproximada de la persona a partir del año actual.
     *
     * @return edad de la persona en años
     */
    public int edad() {
        Calendar fechaHoy = new GregorianCalendar();
        int anioHoy = fechaHoy.get(Calendar.YEAR);

        return anioHoy - anioNacimiento;
    }

    /**
     * Construye el nombre completo de la persona.
     *
     * @return nombre y apellido separados por un espacio
     */
    public String nomYAp() {
        return getNombre() + " " + getApellido();
    }

    /**
     * Muestra por consola los datos principales de la persona.
     */
    public void mostrar() {
        System.out.println("Nombre y Apellido: " + nomYAp());
        System.out.println("DNI: " + getDNI() + " Edad: " + edad() + " años: " + getAnioNacimiento());
    }

}