/**
 * Representa a un docente con su información de cargo, sueldo básico y asignación familiar.
 * 
 * @author luisma
 * @version 1.0
 */
public class Docente {
    /** Nombre del docente. */
    private String nombre;
    /** Grado o curso asignado al docente. */
    private String grado;
    /** Sueldo básico percibido por el docente. */
    private double sueldoBasico;
    /** Monto correspondiente a asignación familiar. */
    private double asignacionFamiliar;

    /**
     * Constructor que inicializa un docente con todos sus atributos.
     * 
     * @param p_nombre nombre del docente
     * @param p_grado grado que enseña
     * @param p_sueldoBasico sueldo básico
     * @param p_asignacionFamiliar asignación familiar
     */
    public Docente(String p_nombre, String p_grado, double p_sueldoBasico, double p_asignacionFamiliar){
        this.setNombre(p_nombre);
        this.setGrado(p_grado);
        this.setSueldoBasico(p_sueldoBasico);
        this.setAsignacionFamiliar(p_asignacionFamiliar);
    }

    /**
     * Asigna el nombre del docente.
     * 
     * @param pNombre nombre a asignar
     */
    public void setNombre(String pNombre) {
        this.nombre = pNombre;
    }

    /**
     * Asigna el monto de asignación familiar.
     * 
     * @param pAsignacionFamiliar monto de asignación a asignar
     */
    public void setAsignacionFamiliar(double pAsignacionFamiliar) {
        this.asignacionFamiliar = Math.max(0.0, pAsignacionFamiliar);
    }

    /**
     * Asigna el grado o curso del docente.
     * 
     * @param pGrado grado a asignar
     */
    public void setGrado(String pGrado) {
        this.grado = pGrado;
    }

    /**
     * Asigna el sueldo básico del docente.
     * 
     * @param p_sueldoBasico sueldo básico a asignar
     */
    public void setSueldoBasico(double p_sueldoBasico) {
        this.sueldoBasico = Math.max(0.0, p_sueldoBasico);
    }

    /**
     * Obtiene la asignación familiar del docente.
     * 
     * @return asignación familiar
     */
    public double getAsignacionFamiliar() {
        return this.asignacionFamiliar;
    }

    /**
     * Obtiene el grado del docente.
     * 
     * @return grado o curso
     */
    public String getGrado() {
        return this.grado;
    }

    /**
     * Obtiene el nombre del docente.
     * 
     * @return nombre del docente
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene el sueldo básico del docente.
     * 
     * @return sueldo básico
     */
    public double getSueldoBasico() {
        return this.sueldoBasico;
    }

    /**
     * Calcula el sueldo total sumando el sueldo básico y la asignación familiar.
     * 
     * @return sueldo total calculado
     */
    public double calcularSueldo(){
        return getAsignacionFamiliar() + getSueldoBasico();
    }    
}