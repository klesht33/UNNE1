/**
 * Representa un círculo geométrico caracterizado por su radio y su punto
 * central.
 * 
 * @author Gabi
 * @version 1.0
 */
public class Circulo {
    /** Radio del círculo. */
    private double radio;
    /** Punto central del círculo. */
    private Punto centro;

    /**
     * Constructor que crea un círculo especificando su radio y su centro.
     * 
     * @param p_radio  radio del círculo
     * @param p_centro punto central del círculo
     */
    public Circulo(double p_radio, Punto p_centro) {
        this.setRadio(p_radio);
        this.setCentro(p_centro != null ? p_centro : new Punto(0, 0));
    }

    /**
     * Constructor por defecto que inicializa el círculo con radio 0 y centro en el
     * origen (0,0).
     */
    public Circulo() {
        this.setRadio(0);
        this.setCentro(new Punto(0, 0));
    }

    /**
     * Asigna el punto centro del círculo.
     * 
     * @param p_centro centro a asignar
     */
    private void setCentro(Punto p_centro) {
        this.centro = p_centro != null ? p_centro : new Punto(0, 0);
    }

    /**
     * Asigna el radio del círculo.
     * 
     * @param p_radio radio a asignar
     */
    private void setRadio(double p_radio) {
        this.radio = Math.max(0.0, p_radio);
    }

    /**
     * Obtiene el punto central del círculo.
     * 
     * @return punto central
     */
    public Punto getCentro() {
        return this.centro;
    }

    /**
     * Obtiene el radio del círculo.
     * 
     * @return radio del círculo
     */
    public double getRadio() {
        return this.radio;
    }

    /**
     * Desplaza la posición del círculo sumando los desplazamientos a las
     * coordenadas del centro.
     * 
     * @param p_dx desplazamiento en el eje X
     * @param p_dy desplazamiento en el eje Y
     */
    public void desplazar(double p_dx, double p_dy) {
        if (this.centro != null) {
            this.centro.desplazar(p_dx, p_dy);
        }
    }

    /**
     * Muestra por consola las características del círculo (centro, radio,
     * superficie y perímetro).
     */
    public void caracteristicas() {
        System.out.println("******Circulo*****");
        String coord = (this.centro != null) ? this.centro.coordenadas() : "(0.0, 0.0)";
        System.out.println("Centro: " + coord + " - Radio: " + getRadio());
        System.out.println("Superficie: " + superficie() + " - Perimetro: " + perimetro());
    }

    /**
     * Calcula la superficie o área del círculo.
     * 
     * @return superficie del círculo
     */
    public double superficie() {
        return Math.PI * Math.pow(getRadio(), 2);
    }

    /**
     * Calcula la distancia entre el centro de este círculo y el centro de otro
     * círculo.
     * 
     * @param p_otroCirculo círculo hasta el cual se calcula la distancia
     * @return distancia entre los centros de ambos círculos
     */
    public double distanciaA(Circulo p_otroCirculo) {
        if (p_otroCirculo == null || p_otroCirculo.getCentro() == null || this.getCentro() == null) {
            return 0.0;
        }
        return this.getCentro().distanciaA(p_otroCirculo.getCentro());
    }

    /**
     * Compara este círculo con otro y devuelve el de mayor superficie.
     * 
     * @param p_otroCirculo círculo con el cual comparar
     * @return el círculo con mayor superficie
     */
    public Circulo elMayor(Circulo p_otroCirculo) {
        if (p_otroCirculo == null) {
            return this;
        }
        if (this.superficie() >= p_otroCirculo.superficie()) {
            return this;
        } else {
            return p_otroCirculo;
        }
    }

    /**
     * Calcula el perímetro (circunferencia) del círculo.
     * 
     * @return perímetro del círculo
     */
    public double perimetro() {
        return 2 * Math.PI * getRadio();
    }
}