/**
 * Representa un Laboratorio con sus datos de contacto y condiciones de compra.
 *
 * @version 1.0
 */
public class Laboratorio {

    /** Nombre del Laboratorio. */
    private String nombre;
    /** Domicilio del Laboratorio. */
    private String domicilio;
    /** Teléfono de contacto del Laboratorio. */
    private String telefono;
    /** Importe mínimo requerido para realizar una compra. */
    private int compraMinima;
    /** Día programado para la entrega. */
    private int diaEntrega;

    /**
     * Crea un Laboratorio con su nombre, datos de contacto y condiciones
     * comerciales.
     *
     * @param pNombre       nombre del Laboratorio
     * @param pDomicilio    domicilio del Laboratorio
     * @param pTelefono     teléfono de contacto del Laboratorio
     * @param pCompraMinima importe mínimo de compra
     * @param pDiaEntrega   día programado para la entrega
     */
    public Laboratorio(String pNombre, String pDomicilio, String pTelefono, int pCompraMinima, int pDiaEntrega) {
        this.setNombre(pNombre);
        this.setDomicilio(pDomicilio);
        this.setTelefono(pTelefono);
        this.setCompraMinima(pCompraMinima);
        this.setDiaEntrega(pDiaEntrega);
    }

    /**
     * Crea un Laboratorio con su nombre y datos de contacto.
     *
     * @param pNombre    nombre del Laboratorio
     * @param pDomicilio domicilio del Laboratorio
     * @param pTelefono  teléfono de contacto del Laboratorio
     */
    public Laboratorio(String pNombre, String pDomicilio, String pTelefono) {
        this.setNombre(pNombre);
        this.setDomicilio(pDomicilio);
        this.setTelefono(pTelefono);
        this.setCompraMinima(0);
        this.setDiaEntrega(0);
    }

    /**
     * Actualiza el importe mínimo de compra.
     *
     * @param pCompraMinima nuevo importe mínimo de compra
     */
    public void nuevaCompraMinima(int pCompraMinima) {
        this.compraMinima = pCompraMinima;

    }

    /**
     * Actualiza el día programado para la entrega.
     *
     * @param pDiaEntrega nuevo día de entrega
     */
    public void nuevoDiaEntrega(int pDiaEntrega) {
        this.diaEntrega = pDiaEntrega;

    }

    /**
     * Muestra por consola los datos principales del Laboratorio.
     */
    public void mostrar() {

        System.out.println("Laboratorio: " + getNombre());
        System.out.println("Domicilio: " + getDomicilio() + " Telefono: " + getTelefono());

    }

    /**
     * Asigna el nombre del Laboratorio.
     *
     * @param pNombre nombre que se asignará
     */
    private void setNombre(String pNombre) {

        this.nombre = pNombre;
    }

    /**
     * Asigna el domicilio del Laboratorio.
     *
     * @param pDomicilio domicilio que se asignará
     */
    private void setDomicilio(String pDomicilio) {
        this.domicilio = pDomicilio;
    }

    /**
     * Asigna el teléfono de contacto del Laboratorio.
     *
     * @param pTelefono teléfono que se asignará
     */
    private void setTelefono(String pTelefono) {
        this.telefono = pTelefono;
    }

    /**
     * Asigna el importe mínimo de compra.
     *
     * @param pCompraMinima importe mínimo que se asignará
     */
    private void setCompraMinima(int pCompraMinima) {
        this.compraMinima = pCompraMinima;
    }

    /**
     * Asigna el día de entrega.
     *
     * @param pDiaEntrega día de entrega que se asignará
     */
    private void setDiaEntrega(int pDiaEntrega) {
        this.diaEntrega = pDiaEntrega;
    }

    /**
     * Obtiene el nombre del Laboratorio.
     *
     * @return nombre del Laboratorio
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el domicilio del Laboratorio.
     *
     * @return domicilio del Laboratorio
     */
    public String getDomicilio() {
        return domicilio;
    }

    /**
     * Obtiene el teléfono de contacto del Laboratorio.
     *
     * @return teléfono del Laboratorio
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Obtiene el importe mínimo de compra.
     *
     * @return importe mínimo de compra
     */
    public int getCompraMinima() {
        return compraMinima;
    }

    /**
     * Obtiene el día programado para la entrega.
     *
     * @return día de entrega
     */
    public int getDiaEntrega() {
        return diaEntrega;
    }

}