import javax.swing.JOptionPane;

/**
 * Punto de entrada de la aplicacion para crear y manipular puntos
 * en un plano cartesiano.
 */
public class PuntoMain {

    /**
     * Solicita las coordenadas de un punto mediante cuadros de dialogo,
     * crea el objeto correspondiente, muestra su información y permite
     * desplazarlo.
     *
     * @param p_args argumentos de linea de comandos; no se utilizan.
     */
    public static void main(String[] p_args) {

        double x = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la coordenada X:"));
        double y = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la coordenada Y:"));

        Punto p = new Punto(x, y);
        p.mostrar();
        System.out.println("" + p.coordenadas());

        double dx = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el desplazamiento en X:"));
        double dy = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el desplazamiento en Y:"));

        p.desplazar(dx, dy);

        p.mostrar();
        System.out.println("" + p.coordenadas());

        // agregamos otro punto por parametro

        Punto p2 = new Punto(3, 4);

        // calculamos la distancia entre p1 (el mismo) hasta p2 (el otro punto que es
        // por parametro)

        System.out.println("Distancia entre p1 y p2:" + p.distanciaA(p2));
    }
}