/**
 * Representa una cuenta corriente bancaria con límite al descubierto.
 * 
 * @author luisma
 * @version 1.0
 */
public class CuentaCorriente {
    private int nroCuenta;
    private double saldo = 0;
    private double limiteDescubierto;
    private Persona titular;

    public CuentaCorriente(int pNroCuenta, Persona pTitular) {
        this.setNroCuenta(pNroCuenta);
        this.setTitular(pTitular);
        this.setLimiteDescubierto();
    }

    public CuentaCorriente(int pNroCuenta, Persona pTitular, double pSaldo) {
        this.setNroCuenta(pNroCuenta);
        this.setTitular(pTitular);
        this.setSaldo(pSaldo);
        this.setLimiteDescubierto();
    }

    private void setNroCuenta(int pNroCuenta) {
        this.nroCuenta = pNroCuenta;
    }

    private void setTitular(Persona pTitular) {
        this.titular = pTitular;
    }

    private void setSaldo(double pSaldo) {
        this.saldo = pSaldo;
    }

    private void setLimiteDescubierto() {
        this.limiteDescubierto = 500;
    }

    public int getNroCuenta() {
        return this.nroCuenta;
    }

    public Persona getTitular() {
        return this.titular;
    }

    public double getSaldo() {
        return this.saldo;
    }

    public double getLimiteDescubierto() {
        return this.limiteDescubierto;
    }

    private boolean puedeExtraer(double pImporte) {
        return pImporte <= (getSaldo() + getLimiteDescubierto());
    }

    public void depositar(double pImporte) {
        this.saldo += pImporte;
    }

    public void extraer(double pImporte) {
        if (puedeExtraer(pImporte)) {
            extraccion(pImporte);
        } else {
            System.out.println("No se pudo realizar la extraccion porque el importe supera el saldo mas el limite descubierto ");
        }
    }

    private void extraccion(double pImporte) {
        this.saldo -= pImporte;
    }

    public void mostrar() {
        System.out.println("-Cuenta Corriente-");
        System.out.println("Nro.Cuenta: " + getNroCuenta() + "- Saldo:" + getSaldo());
        System.out.println("Titular: " + getTitular().nomYAp());
        System.out.println("Descubierto: " + getLimiteDescubierto());
    }
}