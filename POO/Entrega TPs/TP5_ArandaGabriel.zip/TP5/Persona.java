import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Representa una persona mediante sus datos personales básicos.
 *
 * @version 1.0
 */
public class Persona {

    /** Documento Nacional de Identidad de la persona. */
    private int dni;
    /** Nombre de la persona. */
    private String nombre;
    /** Apellido de la persona. */
    private String apellido;
    /** Año de nacimiento de la persona. */
    private int anioNacimiento;
    /** Fecha de nacimiento de la persona. */
    private Calendar fechaNacimiento;

    /**
     * Crea una persona con sus datos personales y año de nacimiento.
     *
     * @param dni            Documento Nacional de Identidad de la persona
     * @param nombre         nombre de la persona
     * @param apellido       apellido de la persona
     * @param anioNacimiento año de nacimiento de la persona
     */
    public Persona(int dni, String nombre, String apellido, int anioNacimiento) {
        setDNI(dni);
        setNombre(nombre);
        setApellido(apellido);
        setAnioNacimiento(anioNacimiento);
    }

    /**
     * Crea una persona con sus datos personales y fecha de nacimiento.
     *
     * @param dni             Documento Nacional de Identidad de la persona
     * @param nombre          nombre de la persona
     * @param apellido        apellido de la persona
     * @param fechaNacimiento fecha de nacimiento de la persona
     */
    public Persona(int dni, String nombre, String apellido, Calendar fechaNacimiento) {
        setDNI(dni);
        setNombre(nombre);
        setApellido(apellido);
        setFechaNacimiento(fechaNacimiento);
    }

    /**
     * Asigna el Documento Nacional de Identidad de la persona.
     *
     * @param dni Documento Nacional de Identidad que se asignará
     */
    private void setDNI(int dni) {
        this.dni = dni;
    }

    /**
     * Asigna el nombre de la persona.
     *
     * @param nombre nombre que se asignará
     */
    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Asigna el apellido de la persona.
     *
     * @param apellido apellido que se asignará
     */
    private void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * Asigna el año de nacimiento de la persona y actualiza la fecha de nacimiento.
     *
     * @param anioNacimiento año de nacimiento que se asignará
     */
    private void setAnioNacimiento(int anioNacimiento) {
        this.anioNacimiento = anioNacimiento;
        Calendar fecha = new GregorianCalendar();
        fecha.set(Calendar.YEAR, anioNacimiento);
        this.fechaNacimiento = fecha;
    }

    /**
     * Asigna la fecha de nacimiento de la persona y actualiza el año de nacimiento.
     *
     * @param fechaNacimiento fecha de nacimiento que se asignará
     */
    private void setFechaNacimiento(Calendar fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
        if (fechaNacimiento != null) {
            this.anioNacimiento = fechaNacimiento.get(Calendar.YEAR);
        }
    }

    /**
     * Obtiene el Documento Nacional de Identidad de la persona.
     *
     * @return Documento Nacional de Identidad de la persona
     */
    public int getDNI() {
        return dni;
    }

    /**
     * Obtiene el nombre de la persona.
     *
     * @return nombre de la persona
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el apellido de la persona.
     *
     * @return apellido de la persona
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * Obtiene el año de nacimiento de la persona.
     *
     * @return año de nacimiento de la persona
     */
    public int getAnioNacimiento() {
        if (this.fechaNacimiento != null) {
            return this.fechaNacimiento.get(Calendar.YEAR);
        }
        return anioNacimiento;
    }

    /**
     * Obtiene la fecha de nacimiento de la persona.
     *
     * @return fecha de nacimiento de la persona
     */
    public Calendar getFechaNacimiento() {
        return this.fechaNacimiento;
    }

    /**
     * Calcula la edad de la persona a partir de la fecha de nacimiento o año de nacimiento.
     *
     * @return edad de la persona en años
     */
    public int edad() {
        Calendar hoy = new GregorianCalendar();
        if (this.getFechaNacimiento() != null) {
            int edad = hoy.get(Calendar.YEAR) - this.getFechaNacimiento().get(Calendar.YEAR);
            if (hoy.get(Calendar.MONTH) < this.getFechaNacimiento().get(Calendar.MONTH) ||
                (hoy.get(Calendar.MONTH) == this.getFechaNacimiento().get(Calendar.MONTH) &&
                 hoy.get(Calendar.DAY_OF_MONTH) < this.getFechaNacimiento().get(Calendar.DAY_OF_MONTH))) {
                edad--;
            }
            return Math.max(0, edad);
        }
        return hoy.get(Calendar.YEAR) - this.getAnioNacimiento();
    }

    /**
     * Determina si la fecha actual coincide con el día y mes de nacimiento de la persona.
     *
     * @return true si hoy es el cumpleaños de la persona, false en caso contrario
     */
    public boolean esCumpleaños() {
        if (this.getFechaNacimiento() == null) {
            return false;
        }
        Calendar hoy = new GregorianCalendar();
        return hoy.get(Calendar.MONTH) == this.getFechaNacimiento().get(Calendar.MONTH)
                && hoy.get(Calendar.DAY_OF_MONTH) == this.getFechaNacimiento().get(Calendar.DAY_OF_MONTH);
    }

    /**
     * Variante para compatibilidad sin caracteres especiales.
     *
     * @return true si hoy es el cumpleaños de la persona, false en caso contrario
     */
    public boolean esCumpleanios() {
        return this.esCumpleaños();
    }

    /**
     * Construye el nombre completo de la persona.
     *
     * @return nombre y apellido separados por un espacio
     */
    public String nomYAp() {
        return getNombre() + " " + getApellido();
    }

    /**
     * Muestra por consola los datos principales de la persona.
     */
    public void mostrar() {
        System.out.println("Nombre y Apellido: " + nomYAp());
        System.out.println("DNI: " + getDNI() + " Edad: " + edad() + " años");
    }
}
